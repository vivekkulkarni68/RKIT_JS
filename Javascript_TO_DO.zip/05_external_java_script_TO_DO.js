/**
 * Created by vivekkulkarni on 7/19/16.
 */

function hideAndSeekContent(btn,id,ele,flag){
    //TODO #1 dispaly button with given id
    if(!flag) {

       //TODO #2 hide the current btn
        //TODO#3 show content of the element(ele)
    }else {
        //TODO #4 hide the current btn
        //TODO#5 hide content of the element(ele)
    }
}
