

var validArrayFunctions = ["toString",
    "toLocaleString",
    "join",
    "pop",
    "push",
    "concat",
    "reverse",
    "shift",
    "unshift",
    "slice",
    "splice",
    "sort",
    "indexOf",
    "lastIndexOf"];

var funNameObjMap={};
//TODO  fill out funObjMap with key being function name from array and value : function object
//Hint : read api docs for Object.getOwnPropertyDescriptor
console.log(funNameObjMap);




