/**
 * Created by vivekkulkarni on 7/22/16.
 */
//Creating entire product catalogue of a company using assign()
    //TODO #1 add appropritae directive for support of "class"
    'use strict';
//TODO Declare a class Books with following properties
//a. category
//b. array of bookNames
//TODO Provide a parameterized constructor to take these to args
//TODO initialize the properties in constructor

//TODO declare an empty class MyShop
//TODO declare another empty class called Mall
//TODO create 3 instances of  Books with following data
      //Books1 category : "history"
              // book names : 'MhabharatItihas','Ramayan Kalin Itihas';
      //Books2 category : "science"
              // book names :"physics","chemistry"
      //Books3 category : "Languages"
             // book names : "Sanskrit","Marathi","Hindi"
//TODO : Merge these 3 categories with object of MyShop.
//TODO : close myShop to get yourSHop
//TODO : Are cloned object and newly created object same in memory ?
var myShop = new MyShop();


var yourShop = new Mall();


